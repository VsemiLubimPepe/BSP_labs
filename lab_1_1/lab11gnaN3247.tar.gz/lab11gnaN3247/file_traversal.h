#ifndef FILE_TRAVERSAL_H

#define FILE_TRAVERSAL_H

int file_traversal(char* dir_path, char* search_mask);

#endif
