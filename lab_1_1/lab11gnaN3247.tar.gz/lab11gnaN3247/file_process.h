#ifndef FILE_PROCESS_H

#define FILE_PROCESS_H

int file_process(char* file_path, char* search_mask);

#endif
